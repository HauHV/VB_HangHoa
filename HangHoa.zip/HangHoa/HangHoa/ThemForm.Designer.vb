﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ThemForm
    Inherits DevExpress.XtraEditors.XtraForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.DxErrorProvider1 = New DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider(Me.components)
        Me.txtHangTon = New DevExpress.XtraEditors.TextEdit
        Me.btnXoaThayDoi = New DevExpress.XtraEditors.SimpleButton
        Me.btnDong = New DevExpress.XtraEditors.SimpleButton
        Me.btnLuuDong = New DevExpress.XtraEditors.SimpleButton
        Me.btnLuu = New DevExpress.XtraEditors.SimpleButton
        Me.ThoiGianTao = New DevExpress.XtraEditors.DateEdit
        Me.txtGiaBan2 = New DevExpress.XtraEditors.TextEdit
        Me.txtTenHang = New DevExpress.XtraEditors.TextEdit
        Me.txtMaHang = New DevExpress.XtraEditors.TextEdit
        Me.LabelControl6 = New DevExpress.XtraEditors.LabelControl
        Me.LabelControl5 = New DevExpress.XtraEditors.LabelControl
        Me.LabelControl4 = New DevExpress.XtraEditors.LabelControl
        Me.LabelControl3 = New DevExpress.XtraEditors.LabelControl
        Me.LabelControl2 = New DevExpress.XtraEditors.LabelControl
        Me.LabelControl1 = New DevExpress.XtraEditors.LabelControl
        Me.txtGiaBan1 = New DevExpress.XtraEditors.TextEdit
        CType(Me.DxErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtHangTon.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ThoiGianTao.Properties.VistaTimeProperties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ThoiGianTao.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtGiaBan2.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTenHang.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtMaHang.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtGiaBan1.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DxErrorProvider1
        '
        Me.DxErrorProvider1.ContainerControl = Me
        '
        'txtHangTon
        '
        Me.txtHangTon.Location = New System.Drawing.Point(110, 103)
        Me.txtHangTon.Name = "txtHangTon"
        Me.txtHangTon.Properties.Mask.EditMask = "n0"
        Me.txtHangTon.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.txtHangTon.Size = New System.Drawing.Size(109, 20)
        Me.txtHangTon.TabIndex = 16
        '
        'btnXoaThayDoi
        '
        Me.btnXoaThayDoi.Image = Global.HangHoa.My.Resources.Resources.CMD_UNDO01
        Me.btnXoaThayDoi.Location = New System.Drawing.Point(112, 258)
        Me.btnXoaThayDoi.Name = "btnXoaThayDoi"
        Me.btnXoaThayDoi.Size = New System.Drawing.Size(97, 23)
        Me.btnXoaThayDoi.TabIndex = 15
        Me.btnXoaThayDoi.Text = "Xóa thay đổi"
        '
        'btnDong
        '
        Me.btnDong.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnDong.Appearance.Options.UseFont = True
        Me.btnDong.Image = Global.HangHoa.My.Resources.Resources.CMD_EXIT01
        Me.btnDong.Location = New System.Drawing.Point(462, 258)
        Me.btnDong.Name = "btnDong"
        Me.btnDong.Size = New System.Drawing.Size(63, 23)
        Me.btnDong.TabIndex = 14
        Me.btnDong.Text = "Đóng"
        '
        'btnLuuDong
        '
        Me.btnLuuDong.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btnLuuDong.Appearance.Options.UseFont = True
        Me.btnLuuDong.Image = Global.HangHoa.My.Resources.Resources.iItemDisk01_16
        Me.btnLuuDong.Location = New System.Drawing.Point(336, 258)
        Me.btnLuuDong.Name = "btnLuuDong"
        Me.btnLuuDong.Size = New System.Drawing.Size(97, 23)
        Me.btnLuuDong.TabIndex = 13
        Me.btnLuuDong.Text = "Lưu và đóng"
        '
        'btnLuu
        '
        Me.btnLuu.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btnLuu.Appearance.Options.UseFont = True
        Me.btnLuu.Image = Global.HangHoa.My.Resources.Resources.iItemDisk01_16
        Me.btnLuu.Location = New System.Drawing.Point(233, 258)
        Me.btnLuu.Name = "btnLuu"
        Me.btnLuu.Size = New System.Drawing.Size(75, 23)
        Me.btnLuu.TabIndex = 12
        Me.btnLuu.Text = "Lưu"
        '
        'ThoiGianTao
        '
        Me.ThoiGianTao.EditValue = Nothing
        Me.ThoiGianTao.Location = New System.Drawing.Point(110, 193)
        Me.ThoiGianTao.Name = "ThoiGianTao"
        Me.ThoiGianTao.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.ThoiGianTao.Properties.Mask.EditMask = "dd/mm/yyyy"
        Me.ThoiGianTao.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.DateTimeAdvancingCaret
        Me.ThoiGianTao.Properties.VistaTimeProperties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton})
        Me.ThoiGianTao.Size = New System.Drawing.Size(109, 20)
        Me.ThoiGianTao.TabIndex = 10
        '
        'txtGiaBan2
        '
        Me.txtGiaBan2.Location = New System.Drawing.Point(110, 164)
        Me.txtGiaBan2.Name = "txtGiaBan2"
        Me.txtGiaBan2.Properties.Mask.EditMask = "N2"
        Me.txtGiaBan2.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.txtGiaBan2.Size = New System.Drawing.Size(181, 20)
        Me.txtGiaBan2.TabIndex = 9
        '
        'txtTenHang
        '
        Me.txtTenHang.Location = New System.Drawing.Point(110, 77)
        Me.txtTenHang.Name = "txtTenHang"
        Me.txtTenHang.Properties.Mask.EditMask = ".+"
        Me.txtTenHang.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx
        Me.txtTenHang.Size = New System.Drawing.Size(181, 20)
        Me.txtTenHang.TabIndex = 7
        '
        'txtMaHang
        '
        Me.txtMaHang.Location = New System.Drawing.Point(110, 50)
        Me.txtMaHang.Name = "txtMaHang"
        Me.txtMaHang.Properties.Mask.EditMask = ".+"
        Me.txtMaHang.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx
        Me.txtMaHang.Size = New System.Drawing.Size(181, 20)
        Me.txtMaHang.TabIndex = 6
        '
        'LabelControl6
        '
        Me.LabelControl6.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl6.Location = New System.Drawing.Point(44, 195)
        Me.LabelControl6.Name = "LabelControl6"
        Me.LabelControl6.Size = New System.Drawing.Size(52, 15)
        Me.LabelControl6.TabIndex = 5
        Me.LabelControl6.Text = "Ngày Tạo"
        '
        'LabelControl5
        '
        Me.LabelControl5.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl5.Location = New System.Drawing.Point(44, 166)
        Me.LabelControl5.Name = "LabelControl5"
        Me.LabelControl5.Size = New System.Drawing.Size(54, 15)
        Me.LabelControl5.TabIndex = 4
        Me.LabelControl5.Text = "Giá Bán 2"
        '
        'LabelControl4
        '
        Me.LabelControl4.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl4.Location = New System.Drawing.Point(44, 137)
        Me.LabelControl4.Name = "LabelControl4"
        Me.LabelControl4.Size = New System.Drawing.Size(54, 15)
        Me.LabelControl4.TabIndex = 3
        Me.LabelControl4.Text = "Giá Bán 1"
        '
        'LabelControl3
        '
        Me.LabelControl3.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl3.Location = New System.Drawing.Point(44, 108)
        Me.LabelControl3.Name = "LabelControl3"
        Me.LabelControl3.Size = New System.Drawing.Size(57, 15)
        Me.LabelControl3.TabIndex = 2
        Me.LabelControl3.Text = "Hàng Tồn "
        '
        'LabelControl2
        '
        Me.LabelControl2.AllowHtmlString = True
        Me.LabelControl2.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl2.Location = New System.Drawing.Point(44, 79)
        Me.LabelControl2.Name = "LabelControl2"
        Me.LabelControl2.Size = New System.Drawing.Size(65, 15)
        Me.LabelControl2.TabIndex = 1
        Me.LabelControl2.Text = "Tên Hàng <Color=Red><b> *</b></Color>" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'LabelControl1
        '
        Me.LabelControl1.AllowHtmlString = True
        Me.LabelControl1.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl1.Location = New System.Drawing.Point(44, 50)
        Me.LabelControl1.Name = "LabelControl1"
        Me.LabelControl1.Size = New System.Drawing.Size(57, 15)
        Me.LabelControl1.TabIndex = 0
        Me.LabelControl1.Text = "Mã Hàng<Color=Red><b> *</b></Color>"
        '
        'txtGiaBan1
        '
        Me.txtGiaBan1.Location = New System.Drawing.Point(110, 135)
        Me.txtGiaBan1.Name = "txtGiaBan1"
        Me.txtGiaBan1.Properties.Mask.EditMask = "n2"
        Me.txtGiaBan1.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.txtGiaBan1.Size = New System.Drawing.Size(181, 20)
        Me.txtGiaBan1.TabIndex = 17
        '
        'ThemForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(559, 323)
        Me.Controls.Add(Me.txtGiaBan1)
        Me.Controls.Add(Me.txtHangTon)
        Me.Controls.Add(Me.btnXoaThayDoi)
        Me.Controls.Add(Me.btnDong)
        Me.Controls.Add(Me.btnLuuDong)
        Me.Controls.Add(Me.btnLuu)
        Me.Controls.Add(Me.ThoiGianTao)
        Me.Controls.Add(Me.txtGiaBan2)
        Me.Controls.Add(Me.txtTenHang)
        Me.Controls.Add(Me.txtMaHang)
        Me.Controls.Add(Me.LabelControl6)
        Me.Controls.Add(Me.LabelControl5)
        Me.Controls.Add(Me.LabelControl4)
        Me.Controls.Add(Me.LabelControl3)
        Me.Controls.Add(Me.LabelControl2)
        Me.Controls.Add(Me.LabelControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "ThemForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Thêm hàng hóa mới"
        CType(Me.DxErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtHangTon.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ThoiGianTao.Properties.VistaTimeProperties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ThoiGianTao.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtGiaBan2.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTenHang.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtMaHang.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtGiaBan1.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DxErrorProvider1 As DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider
    Friend WithEvents txtGiaBan1 As DevExpress.XtraEditors.TextEdit
    Friend WithEvents txtHangTon As DevExpress.XtraEditors.TextEdit
    Friend WithEvents btnXoaThayDoi As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnDong As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnLuuDong As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnLuu As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents ThoiGianTao As DevExpress.XtraEditors.DateEdit
    Friend WithEvents txtGiaBan2 As DevExpress.XtraEditors.TextEdit
    Friend WithEvents txtTenHang As DevExpress.XtraEditors.TextEdit
    Friend WithEvents txtMaHang As DevExpress.XtraEditors.TextEdit
    Friend WithEvents LabelControl6 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl5 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl4 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl3 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl2 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl1 As DevExpress.XtraEditors.LabelControl
End Class
