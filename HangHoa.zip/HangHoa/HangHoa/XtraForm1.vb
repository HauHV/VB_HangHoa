﻿Imports System.Linq

Public Class XtraForm1

    Private Sub Form1_HandleCreated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.HandleCreated
        DevExpress.Skins.SkinManager.EnableFormSkins()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim db As New database1DataContext
        'GridControl1.DataSource = db.tblHangHoas.ToList


        Dim query = From hh In db.tblHangHoas _
                    Order By hh.TenHang Select hh
        GridControl1.DataSource = query
        'RefreshData()

        'Dim anew = New tblHangHoa
        'anew.GiaBan2 = 0
        'db.tblHangHoas.InsertOnSubmit(anew)
        'db.SubmitChanges()

        'Dim mNew = db.tblHangHoas.Where(Function(p) p.MaHang.Equals(GridView1.GetFocusedRowCellValue("MaHang")))
        'db.tblHangHoas.DeleteAllOnSubmit(mNew)
        'db.SubmitChanges()
    End Sub


    Private Sub SimpleButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SimpleButton1.Click
        ThemForm.Show()

    End Sub

    Private Sub GridControl1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GridControl1.Click

    End Sub

    Private Sub BarButtonItem1_ItemClick(ByVal sender As System.Object, ByVal e As DevExpress.XtraBars.ItemClickEventArgs) Handles BarButtonItem1.ItemClick

    End Sub
End Class