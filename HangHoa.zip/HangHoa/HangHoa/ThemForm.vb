﻿Public Class ThemForm
    'Khai báo DataContext
    Dim db As New database1DataContext

    Private _MaHang As String
    Private FormMode As eFormMode
    Public Enum eFormMode
        None = 0
        Them = 1
        Xem = 2
        Sua = 3
    End Enum

    Public Event ThemXong()

    Public Sub New()
        InitializeComponent()
    End Sub
    Public Sub New(ByVal pFormMode As eFormMode, ByVal pMaHang As String)
        InitializeComponent()
        FormMode = pFormMode
        _MaHang = pMaHang
    End Sub
    'Tạo DX form
    Private Sub ThemForm_HandleCreated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.HandleCreated
        DevExpress.Skins.SkinManager.EnableFormSkins()
    End Sub

    'Hàm thêm hàng hóa
    Private Sub ThemFunction()
        'Dim db As New database1DataContext
        'Dim anew = New tblHangHoa
        'anew.GiaBan2 = 0
        'db.tblHangHoas.InsertOnSubmit(anew)
        'db.SubmitChanges()

        If txtMaHang.EditValue = "" Or txtTenHang.EditValue = "" Then
            DxErrorProvider1.SetError(txtMaHang, "Dữ liệu không được trống")
            DxErrorProvider1.SetError(txtTenHang, "Dữ liệu không được trống")
        Else
            Dim anew = New tblHangHoa
            anew.MaHang = txtMaHang.EditValue
            anew.TenHang = txtTenHang.EditValue
            anew.HangTon = txtHangTon.EditValue
            anew.GiaBan1 = txtGiaBan1.EditValue
            anew.GiaBan2 = txtGiaBan2.EditValue
            anew.ThoiGianTao = ThoiGianTao.EditValue

            db.tblHangHoas.InsertOnSubmit(anew)
            db.SubmitChanges()

            RaiseEvent ThemXong()
        End If

    End Sub

    Private Sub RefreshThemForm()
        txtMaHang.EditValue = Nothing
        txtTenHang.EditValue = Nothing
        txtHangTon.EditValue = 0.0
        txtGiaBan1.EditValue = 0.0
        txtGiaBan2.EditValue = 0.0

    End Sub

    Private Sub SuaFunction()
        If txtMaHang.EditValue = "" Or txtTenHang.EditValue = "" Then
            DxErrorProvider1.SetError(txtMaHang, "Dữ liệu không được trống")
            DxErrorProvider1.SetError(txtTenHang, "Dữ liệu không được trống")
        Else
            Dim db = New database1DataContext
            Dim mData = db.tblHangHoas.FirstOrDefault(Function(p) p.MaHang.Equals(_MaHang))
            With mData

                mData.MaHang = txtMaHang.EditValue
                mData.TenHang = txtTenHang.EditValue
                mData.HangTon = txtHangTon.EditValue
                mData.GiaBan1 = txtGiaBan1.EditValue
                mData.GiaBan2 = txtGiaBan2.EditValue
                mData.ThoiGianTao = ThoiGianTao.EditValue
            End With

            db.SubmitChanges()
            RaiseEvent ThemXong()
        End If
    End Sub

    Private Sub btnLuu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLuu.Click
       
        ThemFunction()
        RefreshThemForm()
    End Sub

    Private Sub btnLuuDong_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLuuDong.Click
        Select Case FormMode
            Case eFormMode.Them
                ThemFunction()
                Me.Close()
            Case eFormMode.Sua
                SuaFunction()
                Me.Close()
        End Select

    End Sub

    Private Sub btnXoaThayDoi_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnXoaThayDoi.Click
        RefreshThemForm()
    End Sub

    Private Sub btnDong_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDong.Click
        Me.Close()
    End Sub

    Private Sub ThemForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Select Case FormMode
            Case eFormMode.Them
                ' nothing
            Case eFormMode.Sua
                Dim db = New database1DataContext
                Dim mData = db.tblHangHoas.FirstOrDefault(Function(p) p.MaHang.Equals(_MaHang))
                With mData
                    txtMaHang.EditValue = mData.MaHang
                    txtTenHang.EditValue = mData.TenHang
                    txtHangTon.EditValue = mData.HangTon
                    txtGiaBan1.EditValue = mData.GiaBan1
                    txtGiaBan2.EditValue = mData.GiaBan2
                    ThoiGianTao.EditValue = mData.ThoiGianTao
                End With
                btnLuu.Visible = False
                'btnLuuDong.Visible = False
                btnXoaThayDoi.Visible = False
            Case eFormMode.Xem
                Dim db = New database1DataContext
                Dim mData = db.tblHangHoas.FirstOrDefault(Function(p) p.MaHang.Equals(_MaHang))
                With mData
                    txtMaHang.EditValue = mData.MaHang
                    txtTenHang.EditValue = mData.TenHang
                    txtHangTon.EditValue = mData.HangTon
                    txtGiaBan1.EditValue = mData.GiaBan1
                    txtGiaBan2.EditValue = mData.GiaBan2
                    ThoiGianTao.EditValue = mData.ThoiGianTao
                End With
                btnLuu.Visible = False
                btnLuuDong.Visible = False
                btnXoaThayDoi.Visible = False
        End Select
    End Sub

End Class