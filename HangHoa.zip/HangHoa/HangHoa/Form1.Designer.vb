﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SimpleButton1 = New DevExpress.XtraEditors.SimpleButton
        Me.GridControl1 = New DevExpress.XtraGrid.GridControl
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.grdColMaHang = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColTenHang = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColHangTon = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColGiaBan1 = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColGiaBan2 = New DevExpress.XtraGrid.Columns.GridColumn
        Me.grdColThoiGianTao = New DevExpress.XtraGrid.Columns.GridColumn
        Me.GridView2 = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.SimpleButton2 = New DevExpress.XtraEditors.SimpleButton
        Me.SimpleButton3 = New DevExpress.XtraEditors.SimpleButton
        Me.SimpleButton4 = New DevExpress.XtraEditors.SimpleButton
        Me.SimpleButton5 = New DevExpress.XtraEditors.SimpleButton
        Me.SimpleButton6 = New DevExpress.XtraEditors.SimpleButton
        CType(Me.GridControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SimpleButton1
        '
        Me.SimpleButton1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SimpleButton1.Appearance.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SimpleButton1.Appearance.Options.UseFont = True
        Me.SimpleButton1.Image = Global.HangHoa.My.Resources.Resources.add
        Me.SimpleButton1.ImageLocation = DevExpress.XtraEditors.ImageLocation.MiddleLeft
        Me.SimpleButton1.Location = New System.Drawing.Point(545, 382)
        Me.SimpleButton1.Name = "SimpleButton1"
        Me.SimpleButton1.Size = New System.Drawing.Size(78, 27)
        Me.SimpleButton1.TabIndex = 0
        Me.SimpleButton1.Text = "Thêm"
        '
        'GridControl1
        '
        Me.GridControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GridControl1.Location = New System.Drawing.Point(0, 51)
        Me.GridControl1.MainView = Me.GridView1
        Me.GridControl1.Name = "GridControl1"
        Me.GridControl1.Size = New System.Drawing.Size(703, 325)
        Me.GridControl1.TabIndex = 1
        Me.GridControl1.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.GridView1, Me.GridView2})
        '
        'GridView1
        '
        Me.GridView1.Appearance.EvenRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.EvenRow.Options.UseFont = True
        Me.GridView1.Appearance.FocusedCell.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.FocusedCell.Options.UseFont = True
        Me.GridView1.Appearance.FocusedRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.FocusedRow.Options.UseFont = True
        Me.GridView1.Appearance.HeaderPanel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.HeaderPanel.Options.UseFont = True
        Me.GridView1.Appearance.HeaderPanel.Options.UseTextOptions = True
        Me.GridView1.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.GridView1.Appearance.HideSelectionRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.HideSelectionRow.Options.UseFont = True
        Me.GridView1.Appearance.HorzLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.HorzLine.Options.UseFont = True
        Me.GridView1.Appearance.OddRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.OddRow.Options.UseFont = True
        Me.GridView1.Appearance.Row.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.Row.Options.UseFont = True
        Me.GridView1.Appearance.RowSeparator.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.RowSeparator.Options.UseFont = True
        Me.GridView1.Appearance.SelectedRow.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.SelectedRow.Options.UseFont = True
        Me.GridView1.Appearance.VertLine.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridView1.Appearance.VertLine.Options.UseFont = True
        Me.GridView1.Columns.AddRange(New DevExpress.XtraGrid.Columns.GridColumn() {Me.grdColMaHang, Me.grdColTenHang, Me.grdColHangTon, Me.grdColGiaBan1, Me.grdColGiaBan2, Me.grdColThoiGianTao})
        Me.GridView1.GridControl = Me.GridControl1
        Me.GridView1.Name = "GridView1"
        Me.GridView1.OptionsView.EnableAppearanceEvenRow = True
        Me.GridView1.OptionsView.EnableAppearanceOddRow = True
        Me.GridView1.OptionsView.ShowAutoFilterRow = True
        Me.GridView1.OptionsView.ShowFooter = True
        '
        'grdColMaHang
        '
        Me.grdColMaHang.Caption = "Ma Hang"
        Me.grdColMaHang.FieldName = "MaHang"
        Me.grdColMaHang.Name = "grdColMaHang"
        Me.grdColMaHang.OptionsColumn.ReadOnly = True
        Me.grdColMaHang.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains
        Me.grdColMaHang.Visible = True
        Me.grdColMaHang.VisibleIndex = 0
        '
        'grdColTenHang
        '
        Me.grdColTenHang.Caption = "Ten hang"
        Me.grdColTenHang.FieldName = "TenHang"
        Me.grdColTenHang.Name = "grdColTenHang"
        Me.grdColTenHang.OptionsColumn.ReadOnly = True
        Me.grdColTenHang.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains
        Me.grdColTenHang.Visible = True
        Me.grdColTenHang.VisibleIndex = 1
        '
        'grdColHangTon
        '
        Me.grdColHangTon.Caption = "Ton"
        Me.grdColHangTon.DisplayFormat.FormatString = "N2"
        Me.grdColHangTon.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric
        Me.grdColHangTon.FieldName = "HangTon"
        Me.grdColHangTon.Name = "grdColHangTon"
        Me.grdColHangTon.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Equals
        Me.grdColHangTon.Visible = True
        Me.grdColHangTon.VisibleIndex = 2
        '
        'grdColGiaBan1
        '
        Me.grdColGiaBan1.Caption = "GiaBan1"
        Me.grdColGiaBan1.DisplayFormat.FormatString = "N0"
        Me.grdColGiaBan1.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric
        Me.grdColGiaBan1.FieldName = "GiaBan1"
        Me.grdColGiaBan1.Name = "grdColGiaBan1"
        Me.grdColGiaBan1.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Equals
        Me.grdColGiaBan1.Visible = True
        Me.grdColGiaBan1.VisibleIndex = 3
        '
        'grdColGiaBan2
        '
        Me.grdColGiaBan2.Caption = "GiaBan2"
        Me.grdColGiaBan2.DisplayFormat.FormatString = "N0"
        Me.grdColGiaBan2.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric
        Me.grdColGiaBan2.FieldName = "GiaBan2"
        Me.grdColGiaBan2.Name = "grdColGiaBan2"
        Me.grdColGiaBan2.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Equals
        Me.grdColGiaBan2.Visible = True
        Me.grdColGiaBan2.VisibleIndex = 4
        '
        'grdColThoiGianTao
        '
        Me.grdColThoiGianTao.Caption = "ThoiGianTao"
        Me.grdColThoiGianTao.DisplayFormat.FormatString = "dd/MM/yyyy HH:mm:ss"
        Me.grdColThoiGianTao.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime
        Me.grdColThoiGianTao.FieldName = "ThoiGianTao"
        Me.grdColThoiGianTao.Name = "grdColThoiGianTao"
        Me.grdColThoiGianTao.OptionsColumn.AllowEdit = False
        Me.grdColThoiGianTao.OptionsColumn.AllowFocus = False
        Me.grdColThoiGianTao.OptionsColumn.ReadOnly = True
        Me.grdColThoiGianTao.Visible = True
        Me.grdColThoiGianTao.VisibleIndex = 5
        '
        'GridView2
        '
        Me.GridView2.GridControl = Me.GridControl1
        Me.GridView2.Name = "GridView2"
        '
        'SimpleButton2
        '
        Me.SimpleButton2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SimpleButton2.Appearance.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SimpleButton2.Appearance.Options.UseFont = True
        Me.SimpleButton2.Image = Global.HangHoa.My.Resources.Resources.delete1
        Me.SimpleButton2.ImageLocation = DevExpress.XtraEditors.ImageLocation.MiddleLeft
        Me.SimpleButton2.Location = New System.Drawing.Point(629, 382)
        Me.SimpleButton2.Name = "SimpleButton2"
        Me.SimpleButton2.Size = New System.Drawing.Size(62, 27)
        Me.SimpleButton2.TabIndex = 2
        Me.SimpleButton2.Text = "Xóa"
        '
        'SimpleButton3
        '
        Me.SimpleButton3.Location = New System.Drawing.Point(13, 13)
        Me.SimpleButton3.Name = "SimpleButton3"
        Me.SimpleButton3.Size = New System.Drawing.Size(68, 23)
        Me.SimpleButton3.TabIndex = 3
        Me.SimpleButton3.Text = "Khách hàng"
        '
        'SimpleButton4
        '
        Me.SimpleButton4.Location = New System.Drawing.Point(91, 13)
        Me.SimpleButton4.Name = "SimpleButton4"
        Me.SimpleButton4.Size = New System.Drawing.Size(68, 23)
        Me.SimpleButton4.TabIndex = 4
        Me.SimpleButton4.Text = "Hàng Hóa"
        '
        'SimpleButton5
        '
        Me.SimpleButton5.Location = New System.Drawing.Point(168, 13)
        Me.SimpleButton5.Name = "SimpleButton5"
        Me.SimpleButton5.Size = New System.Drawing.Size(68, 23)
        Me.SimpleButton5.TabIndex = 5
        Me.SimpleButton5.Text = "Nhân viên"
        '
        'SimpleButton6
        '
        Me.SimpleButton6.Location = New System.Drawing.Point(247, 13)
        Me.SimpleButton6.Name = "SimpleButton6"
        Me.SimpleButton6.Size = New System.Drawing.Size(68, 23)
        Me.SimpleButton6.TabIndex = 6
        Me.SimpleButton6.Text = "Thiết bị"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(703, 421)
        Me.Controls.Add(Me.SimpleButton6)
        Me.Controls.Add(Me.SimpleButton5)
        Me.Controls.Add(Me.SimpleButton4)
        Me.Controls.Add(Me.SimpleButton3)
        Me.Controls.Add(Me.SimpleButton2)
        Me.Controls.Add(Me.GridControl1)
        Me.Controls.Add(Me.SimpleButton1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.GridControl1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SimpleButton1 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents GridControl1 As DevExpress.XtraGrid.GridControl
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents GridView2 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents SimpleButton2 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents SimpleButton3 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents SimpleButton4 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents SimpleButton5 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents SimpleButton6 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents grdColMaHang As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColTenHang As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColHangTon As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColGiaBan1 As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColGiaBan2 As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents grdColThoiGianTao As DevExpress.XtraGrid.Columns.GridColumn

End Class
